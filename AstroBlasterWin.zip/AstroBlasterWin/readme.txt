Mouse for menu
Space to shoot

Original artwork
Beep-7.ogg from http://www.soundjay.com/tos.html
Music by Kevin MacLeod at http://incompetech.com/

AVBIN License
-------

Due to the linkage between AVbin and FFmpeg, AVbin must be licensed under the
LGPL or GPL. Currently all GPL features of the FFmpeg configuration are
disabled, permitting LGPL use.

You should see the accompanying COPYING and COPYING.LESSER files for details.
In summary, you must note the usage of FFmpeg and AVbin within the
documentation of your application. If you make changes to either library, you
must include the sources of these changes within your application.